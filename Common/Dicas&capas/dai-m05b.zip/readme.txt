Daisenryaku 2 Manuals in English, ver. 0.5b
Translated by Takamichi, April 17, 2000

1. How to browse
1-1. User's Manual
Put daisen-m.htm and all .GIF and .JPG files in one
folder. Doubleclick daisen-m.htm.

1-2. Reference Book
Doubleclick dairef.htm.

2. About
Two years ago, I, Victor and Trunks were developing
English Daisenryaku 2, the MSX strategy game released
from Microcabin in 1992.
A Daisenryaku 2 package contains two manuals - User's
Manual and Reference Book.
In November, I translated whole User's Manual in one
day in pure text form. No graphics at all. Text version
was available in HTML form in one of my webpages.
Later, we corrected several critical terms and almost
whole weapon names. However, leaving a few weapon names
wrong, development halted.

Later, January 2000, I decided to edit full version
anyway. I took screenshots and pasted them on
locations where original manuals have. I also added
caption numbers in some of pictures.
Of course, I scanned cover picture (F117 plane) and
several others from original Daisenryaku 2 manual.

Almost all of texts are not changed since hastily
translated form they were two years ago. I have not
tampered with fonts and other adorning. I would
like to call current incomplete form as "ver 0.5".

3. Reference Book
Daisenryaku 2 Reference Book tells weapon data, and
also tips for 20 maps playable in Standard (non-campaign)
mode. Translation of this manual is included in this
archive since 2000 April 17.
Page 1 to 20 in this manual are omitted since weapon
data is so bulky and easily browsable during the game
(see pages 20 and 21 of User's Manual). However, 6 pages
of map tips which are not readable in this game are included.

4. About distribution
Unless without written permission, this archive should not
be accessible from anywhere other than following two sites;
http://www.msxnet.org/gtinter/riskm.htm
http://www.bekkoame.ne.jp/i/takatemp/riskm.htm
