TWIN BEE
--------

Wav MSX game

To load the game into the MSX, just follow the steps:

* Extract the .wav file into any directory with a lot of free space.
  Note that the .zip file have a high degree of compression 
  (about 10.000 times - think that 10kb zip file = 1Mb wav file)

* Power up your MSX and connect the EAR jack into the Speaker of the PC sound card.

* At your MSX, execute RUN"cas:" 

* At your PC, put the sound card volume and wave volume at maximum, and tune lows and highs at medium.

* Play the .wav file using the windows multimedia player.

http://msx.hop.to